package tom;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("Data")
public class Database {

	@GET
    @Path("/Add/{name}/{age}")
    public String getdate(@PathParam("name") String name,@PathParam("age") int age)
    {
		Connection cn;
		Statement smt;
		
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "0786");
			smt=cn.createStatement();
			
			String insert="insert into studentnew values('"+name+"','"+age+"')";
			smt.executeUpdate(insert);
		
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}	
		
		return "Data Saved in Database";
    }
	@GET
	@Path("/Delete/{name}")
	public String delete(@PathParam("name") String name)
	{
		
		Connection cn;
		Statement smt;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "0786");
			smt=cn.createStatement();
			
			
			String del="delete from studentnew where name='"+name+"'";
			smt.executeUpdate(del);
			
			smt.close();
			cn.close();
			
		} catch (Exception e)
		{
			System.out.println("hi"+e);
		}
		
		return "Data Deleted form Database";
		
	}
	
	@GET
    @Path("/Update/{name}/{age}")
    public String getdateupdate(@PathParam("name") String name,@PathParam("age") int age)
    {
		Connection cn;
		Statement smt;
		
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "0786");
			smt=cn.createStatement();
			
			String insert="update studentnew set age='"+age+"' where name='"+name+"'";
			smt.executeUpdate(insert);
		
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}	
		
		return "Data Updated in Database";
    }
	
	@GET
	@Path("/show")
	public String show()
	{
		
		Connection cn;
		Statement smt;
		ResultSet rs=null;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "0786");
			smt=cn.createStatement();
			
			
			rs=smt.executeQuery("select * from studentnew");
			
			while(rs.next())
			{
	
				return rs.getString("name")+" "+rs.getInt("age");
				
			}
	
			smt.close();
			
			cn.close();
			
		} catch (Exception e)
		{
			System.out.println("hi"+e);
		}
		
		return null;
		
		
	}
}
