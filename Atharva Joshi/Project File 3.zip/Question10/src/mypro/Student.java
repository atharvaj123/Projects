package mypro;

public class Student {
	
		String Name;
		int id;
		String Location;
		
		public Student(String Name, int id, String Location) {
			this.Name=Name;
			this.id=id;
			this.Location=Location;
		}

		
		public String show(){
		
			return "("+Name+","+id+","+Location+")";
			
		}
}
