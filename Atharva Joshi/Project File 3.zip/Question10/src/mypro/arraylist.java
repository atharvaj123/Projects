package mypro;

import java.util.ArrayList;
import java.util.Iterator;

public class arraylist {

	public static void  main(String args[]){
		
		ArrayList<Student> al=new ArrayList();
		
		Student s=new Student("Atharva",101,"Mumbai");
		Student s1=new Student("Vinayak",102,"Bangalore");
		Student s2=new Student("Nakul",103,"Delhi");
		Student s3=new Student("Rahul",104,"Rajkot");
		Student s4=new Student("Swapnil",105,"Patna");
		
		al.add(s);
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		

		System.out.println("********All Records********");
		Iterator it=al.iterator();
	   
		for(Student ss:al){
			System.out.println(ss.id+" "+ss.Name+" "+ss.Location);
		}
	
		al.remove(s2);
		
		System.out.println("********After Deletion**********");
		
		for(Student ss:al){
			System.out.println(ss.id+" "+ss.Name+" "+ss.Location);
		}

}
}