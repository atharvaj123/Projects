package com.Tom;

public class stude {

	private int id;
	private String name;
	private int English;
	private int Economics;
	private int Maths;
	private int Science;
	private int History;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEnglish() {
		return English;
	}
	public void setEnglish(int english) {
		English = english;
	}
	public int getEconomics() {
		return Economics;
	}
	public void setEconomics(int economics) {
		Economics = economics;
	}
	public int getMaths() {
		return Maths;
	}
	public void setMaths(int maths) {
		Maths = maths;
	}
	public int getScience() {
		return Science;
	}
	public void setScience(int science) {
		Science = science;
	}
	public int getHistory() {
		return History;
	}
	public void setHistory(int history) {
		History = history;
	}
	public double getPer() {
		return per;
	}
	public void setPer(double per) {
		this.per = per;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	private double per;
	private String grade;
	
	
	
	
	
	
	
	
	
}
