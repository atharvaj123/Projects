package com.Tom;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.tool.schema.internal.StandardUniqueKeyExporter;

/**
 * Servlet implementation class addstudentctrl
 */
public class addstudentctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addstudentctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String d=request.getParameter("i");
		
		int id=Integer.parseInt(d);
		
		String name=request.getParameter("nm");
		
		String eco=request.getParameter("p");
		String sci =request.getParameter("c");
		String ma=request.getParameter("m");
		String his=request.getParameter("b");
		String eng=request.getParameter("e");
				
		String grade;
		 
		double m=0;
		
		int economics=Integer.parseInt(eco);
		int science=Integer.parseInt(sci);
		int maths=Integer.parseInt(ma);
		int history=Integer.parseInt(his);
		int english=Integer.parseInt(eng);
		
		double mark=economics+science+maths+history+english;
		
		stude p=new stude();
		p.setId(id);
		p.setName(name);
		p.setEconomics(economics);
		p.setHistory(history);
		p.setMaths(maths);
		p.setScience(science);;
		p.setEnglish(english);
		
		
		Connection cn;
		Statement smt;
		ResultSet rs=null;
		
		if(!name.equals(null))
		{
				p.setPer(mark/500*100);				
				
				if(p.getPer()>=80 && p.getPer()<=100)
				{
					p.setGrade("A");
				}
				else if (p.getPer()>=60 && p.getPer()<=79) 
				{
					p.setGrade("B");
					
				}
				else if (p.getPer()>=50 && p.getPer()<=59) 
				{
					p.setGrade("C");
				}
				
			}
			
		
		
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "0786");
			smt=cn.createStatement();
			
			
			String insert="insert into studentnew1 values('"+p.getId()+"','"+p.getName()+"','"+p.getEconomics()+"','"+p.getScience()+"','"+p.getMaths()+"','"+p.getHistory()+"','"+p.getEnglish()+"','"+p.getPer()+"','"+p.getGrade()+"')";
			smt.executeUpdate(insert);
			System.out.println("data stored...............");
	
			out.println("Data Added To Database");
			smt.close();
			cn.close();
			
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
